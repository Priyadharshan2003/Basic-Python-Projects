verb_1 = input("Enter a verb of choice then press enter :")
adj_1 = input("Enter an adjective of choice :")
verb_2 = input("Enter second verb of choice :")
body_part = input("Enter a body part name of choice :")
adverb = input("Enter an adverb of choice :")
body_part_2 = input("Enter any body name of your choice:")
noun = input("Enter a noun of choice :")
verb_3 = input("Enter the third verb of choice :")
animal = input("Enter name of any animal of choice :")
noun_2 = input("Enter an noun of choice  :")
verb_4 = input("Enter the fourth verb of choice :")
adj_2 = input("Enter an adjective of chioce :")
color = input("Enter any color name :")

story = (
    "Most doctors agree that bicycle of"
    + verb_1
    + " is a/an "
    + adj_1
    + " form of exercise.\n"
    + verb_2
    + " a bicycle enables you to develop your "
    + body_part
    + " muscles as well as "
    + adverb
    + " increase the rate of a "
    + body_part_2
    + " beat. More "
    + noun
    + " around the world "
    + verb_3
    + " bicycles than drive "
    + animal
    + ".\nNo matter what kind of "
    + noun_2
    + "you "
    + verb_4
    + " always be sure to wear a/an "
    + adj_2
    + " helmet.Make sure to have  "
    + color
    + " reflectors too! "
)

print(story)
