# QRCode Scanner
**An app to scan QRcode via image or Webcam available in PC.**

### Tools/FrameWorks used:
 - pyzbar
 - opencv-python
 - numpy

## Installation
Simple, Just clone this repository to your local storage and run the below command.
` pip install -r requirements.txt `

## Execution
Run the below command in command prompt or terminal.
`python3 main.py`
