# IPv4_Calculator

IPv4_Calculator is developed for:
1.Determine the network class (A, B, C);
2.Determine which category the address belongs to (private, public);
3.Determine subnet attributes.
