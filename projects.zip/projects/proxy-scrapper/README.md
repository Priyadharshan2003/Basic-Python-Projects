# Proxy Scrapper

Install BeautifulSoup
```sh
pip3 install beautifulsoup4
```

Run script
```sh
python3 proxy_scrapper.py
```