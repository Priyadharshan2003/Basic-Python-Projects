# Port Scanner

Port Scanner is developed for:
checking if the port is open