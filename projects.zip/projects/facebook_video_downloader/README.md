# Facebook Video Downloader

A python script to download Facebook videos.

## Installation

```
pip install -r requirements.txt
```

## Usage

```
python facebook_video_downloader.py
```

The script will save the video in the downloads folder of the current directory.
