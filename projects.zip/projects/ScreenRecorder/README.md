# Screen Recorder using Python

### First install this modules by enter this lines in your terminal

pip install opencv-python

pip install pywin32

pip install numpy

pip install pyautogui

# Now run the main.py 

## Great.............You Did it, Check your folder and find "ScreenRecord.mp4" file
