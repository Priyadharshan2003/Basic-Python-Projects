## Project Name :
Dual Dice Simulator

<br>

## Project Description :
A simple python program which uses basic concepts to show a simulation of two dices on the screen with their valid output.

<br>

### Project images
![Screenshot from 2022-10-11 01-04-52](https://user-images.githubusercontent.com/97968307/195894277-3c6502ab-8c72-4e4e-90bc-eed7884b67d2.png)

<br>

## Additional Description
- Very Useful when you doubt the judgement and choice of traditional physical dices.
- Run the dice any number of times till the end of the game
- Any further improvements in this project are fully welcomed.
