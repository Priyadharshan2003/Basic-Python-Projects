# Image Toonifier
**An App to toonify images in PC. Have Fun Toonifying yourselves.**

Just apply your images the cartoon effect and Enjoy!!

### Tools/FrameWorks used:
 - opencv-python
 - numpy

## Installation
Simple, Just clone this repository to your local storage and run the below command.
` pip install -r requirements.txt `

## Execution
 - Place your images in the images/Folder

 - Run the below command in command prompt or terminal.
`python3 main.py`

### If something does not work try changing the inner values such as blur value and line size. It should work now.
