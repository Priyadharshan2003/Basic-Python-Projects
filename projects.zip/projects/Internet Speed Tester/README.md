## Internet Speed Tester
Check the Download and Upload Speed of your Internet Connection.

### Requirements.
1. pyspeedtest
2. speedtest
3. speedtest-cli

### How to use
```
./main.py
```
