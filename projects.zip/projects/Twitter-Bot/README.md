## Twitter-RT-Bot

> **Note**

install **tweepy** library before jumping on the code : 
```bash
pip install tweepy
```

Make sure to get your required APIs from Twitter Developers website. It's extremely easy to set up your developer account ang get the APIs for those who haven't yet came across.

This Bot Retweets the Tweets which come on the feed in real-time, you may add different functionalities to your Bot according to your requirements.

By this code You will be able to make a bot which retweet the tweets with information you want it to give.


