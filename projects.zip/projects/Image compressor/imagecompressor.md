*Image Compression using PIL Python library*

It is CLI based program used to compress the images using PIL library.

Fixes #3

*Built With*

Python (PIL Library)

*Prerequisites*
1. `pip install pillow`
2. `pip install argparse`

*Run project in CLI*

`python imageCompressor.py file-name`
