# Text-to-Speech

- This python script basically takes text from user as input and gives output in form of a voice.
- Uses Google Translate Text to Speech API.

### Note:

- Output is available on an audio player.

### Dependencies:

- gTTS
- os
